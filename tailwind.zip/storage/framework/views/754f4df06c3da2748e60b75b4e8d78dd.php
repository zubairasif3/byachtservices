<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
    <!-- Breadcrumb Start -->
    <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between add-heading">
        <h2 class="text-title-md2 font-bold text-black dark:text-white">
            Add Worker
        </h2>

        <nav>
            <ol class="flex items-center gap-2">
                <li>
                    <a class="font-medium" href="<?php echo e(route('dashboard')); ?>">Dashboard /</a>
                </li>
                <li class="font-medium text-primary add-heading">Add Worker</li>
            </ol>
        </nav>
    </div>
    <!-- Breadcrumb End -->

    <!-- Worker Form -->
    <div class="bg-white rounded-md shadow-md border border-stroke p-6 dark:bg-boxdark dark:border-strokedark">
        <form action="<?php echo e(route('workers.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- User -->
                <div>
                    <label for="user_id" class="block text-sm font-medium text-black dark:text-white mb-2">
                        User <span class="text-red-500">*</span>
                    </label>
                    <select
                        id="user_id"
                        name="user_id"
                        class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                        required
                    >
                        <option value="">Select a User</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id', $worker->user_id) == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <!-- Worker Name -->
                <div>
                    <label for="name" class="block text-sm font-medium text-black dark:text-white mb-2">
                        Worker Name <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="<?php echo e(old('name', $worker->name)); ?>"
                        placeholder="Enter worker name"
                        class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                        required
                    />
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Hourly Rate -->
                <div>
                    <label for="hourly_rate" class="block text-sm font-medium text-black dark:text-white mb-2">
                        Hourly Rate <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="number"
                        id="hourly_rate"
                        name="hourly_rate"
                        value="<?php echo e(old('hourly_rate', $worker->hourly_rate)); ?>"
                        placeholder="Enter hourly rate"
                        step="0.01"
                        min="0"
                        class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                        required
                    />
                </div>
                <!-- Hours Worked -->
                <div>
                    <label for="hours_worked" class="block text-sm font-medium text-black dark:text-white mb-2">
                        Hours Worked
                    </label>
                    <input
                        type="number"
                        id="hours_worked"
                        name="hours_worked"
                        value="<?php echo e(old('hours_worked', $worker->hours_worked)); ?>"
                        placeholder="Enter hours worked"
                        step="0.01"
                        min="0"
                        class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                        disabled
                    />
                </div>
            </div>


            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Total Payment -->
                <div>
                    <label for="total_payment" class="block text-sm font-medium text-black dark:text-white mb-2">
                        Total Payment
                    </label>
                    <input
                        type="number"
                        id="total_payment"
                        name="total_payment"
                        value="<?php echo e(old('total_payment', $worker->total_payment)); ?>"
                        placeholder="Enter Total Payment"
                        step="0.01"
                        min="0"
                        class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                        disabled
                    />
                </div>
                <!-- Payment Status -->
                <div>
                    <label for="payment_status" class="block text-sm font-medium text-black dark:text-white mb-2">
                        Payment Status
                    </label>
                    <select
                        id="payment_status"
                        name="payment_status"
                        class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                        <option value="Pending" <?php echo e(old('payment_status', $worker->payment_status) == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="Paid" <?php echo e(old('payment_status', $worker->payment_status) == 'Paid' ? 'selected' : ''); ?>>Paid</option>
                    </select>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="text-right">
                <button
                    type="submit"
                    class="px-6 py-2 rounded bg-primary text-white font-medium hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50"
                >
                    Add Worker
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\byachtservices\byachtservices\resources\views/admin/workers/edit.blade.php ENDPATH**/ ?>