<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
        Bonaveture | Admin Panel
    </title>
    <link rel="icon" href="<?php echo e(asset('assets/images/logo.webp')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
  <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
  
</head>

    <!-- Additional Styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>
<body
  x-data="{ page: 'ecommerce', 'loaded': true, 'darkMode': true, 'stickyMenu': false, 'sidebarToggle': false, 'scrollTop': false }"
  x-init="
        darkMode = JSON.parse(localStorage.getItem('darkMode'));
        $watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))"
  :class="{'dark text-bodydark bg-boxdark-2': darkMode === true}"
>
  <!-- ===== Preloader Start ===== -->
  <div x-show="loaded" x-init="window.addEventListener('DOMContentLoaded', () => {setTimeout(() => loaded = false, 500)})" class="fixed left-0 top-0 z-999999 flex h-screen w-screen items-center justify-center bg-white dark:bg-black">
    <div class="h-16 w-16 animate-spin rounded-full border-4 border-solid border-primary border-t-transparent"></div>
  </div>

    <!-- ===== Preloader End ===== -->

    <!-- ===== Page Wrapper Start ===== -->
    <div class="flex h-screen overflow-hidden">
        <!-- Main Sidebar Container -->
        <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ===== Content Area Start ===== -->
        <div class="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">
            <!-- Navbar -->
            <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- ===== Main Content Start ===== -->
            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        <!-- ===== Main Content End ===== -->
        </div>
        <!-- ===== Content Area End ===== -->
    </div>
  <!-- ===== Page Wrapper End ===== -->
  <script defer src="<?php echo e(asset('assets/js/bundle.js')); ?>"></script>
  <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
        const notificationBell = document.querySelector('[x-data]');

        notificationBell.addEventListener('click', function () {
            fetch(`<?php echo e(url("/notifications/mark-as-read")); ?>`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            }).then(() => {
                const notifyingElement = document.querySelector('[notifying]');
                if (notifyingElement) notifyingElement.classList.add('hidden');
            });
        });
    });
  </script>
</body>
</html>

<?php /**PATH C:\laragon\www\byachtservices\byachtservices\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>