<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
    <!-- Breadcrumb Start -->
    <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 class="text-title-md2 font-bold text-black dark:text-white add-heading">
        Add Customer Inventory
        </h2>

        <nav>
        <ol class="flex items-center gap-2">
            <li>
                <a class="font-medium" href="<?php echo e(route('dashboard')); ?>">Dashboard /</a>
            </li>
            <li class="font-medium text-primary add-heading">Add Customer Inventory</li>
        </ol>
        </nav>
    </div>
    <!-- Breadcrumb End -->

   <!-- Inventory Form -->
   <div class="bg-white rounded-md shadow-md border border-stroke p-6 dark:bg-boxdark dark:border-strokedark">
    <form action="<?php echo e(route('customers_inventory.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Boat Customer -->
            <div>
                <label for="boat_customer" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Boat Customer
                </label>
                <input
                    type="text"
                    id="boat_customer"
                    name="boat_customer"
                    value="<?php echo e(old('boat_customer')); ?>"
                    placeholder="Enter boat customer name"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary" required
                />
            </div>
            <!-- Customer ID -->
            <div>
                <label for="company_owner_id" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Customer <span class="text-red-500">*</span>
                </label>
                <select
                    id="company_owner_id"
                    name="company_owner_id"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    required
                >
                    <option value="">Select a Customer</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>" <?php echo e(old('company_owner_id') == $customer->id ? 'selected' : ''); ?>>
                            <?php echo e($customer->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Box -->
            <div>
                <label for="box" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Box*
                </label>
                <input
                    type="text"
                    id="box"
                    name="box"
                    value="<?php echo e(old('box')); ?>"
                    placeholder="Enter the box name"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                />
            </div>
            <!-- Name -->
            <div>
                <label for="name" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Name <span class="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value="<?php echo e(old('name')); ?>"
                    placeholder="Enter the name of the item"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    required
                />
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Content -->
            <div>
                <label for="content" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Content*
                </label>
                <textarea
                    id="content"
                    name="content"
                    placeholder="Enter the content description"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                ><?php echo e(old('content')); ?></textarea>
            </div>
            <!-- Quantity -->
            <div>
                <label for="quantity" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Quantity <span class="text-red-500">*</span>
                </label>
                <input
                    type="number"
                    id="quantity"
                    name="quantity"
                    value="<?php echo e(old('quantity')); ?>"
                    placeholder="Enter the quantity"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    required
                />
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Serial -->
            <div>
                <label for="serial" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Serial*
                </label>
                <input
                    type="text"
                    id="serial"
                    name="serial"
                    value="<?php echo e(old('serial')); ?>"
                    placeholder="Enter the serial number"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                />
            </div>
            <!-- Description -->
            <div>
                <label for="description" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Description*
                </label>
                <textarea
                    id="description"
                    name="description"
                    placeholder="Enter the item description"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                ><?php echo e(old('description')); ?></textarea>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Approval_status -->
            <div>
                <label for="approval_status" class="block text-sm font-medium text-black dark:text-white mb-2">
                    Status <span class="text-red-500">*</span>
                </label>
                <select
                    id="approval_status"
                    name="approval_status"
                    class="w-full rounded border border-gray-300 px-4 py-2 text-sm text-black dark:border-strokedark dark:bg-form-input dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    required
                >
                    <option value="Pending" <?php echo e(old('approval_status') == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="Approved" <?php echo e(old('approval_status') == 'Approved' ? 'selected' : ''); ?>>Approved</option>
                    <option value="Rejected" <?php echo e(old('approval_status') == 'Rejected' ? 'selected' : ''); ?>>Rejected</option>
                </select>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="text-right">
            <button
                type="submit"
                class="px-6 py-2 rounded bg-primary text-white font-medium hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50 btn-background"
            >
                Add Inventory
            </button>
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\byachtservices\byachtservices\resources\views/admin/customers_inventory/create.blade.php ENDPATH**/ ?>