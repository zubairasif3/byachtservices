@extends('admin.layout.app')
@section('content')
    <div class="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
        <!-- Status Message -->
        @if (session('success'))
            <div class="bg-[#13C296] border flex items-center justify-between mb-4 p-4 rounded text-white">
                <p>{{ session('success') }}</p>
                <button class="text-green-700 hover:text-green-900" onclick="this.parentElement.remove();">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 011.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                </button>
            </div>
        @endif

        <!-- Breadcrumb Start -->
        <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h2 class="flex gap-2 items-center text-title-md2 font-bold text-black dark:text-white add-heading">
                Invoices
                @if (auth()->user()->hasRole('Admin'))
                    <a href="{{ route('invoices.create') }}" class="bg-primary flex gap-2 hover:bg-opacity-80 items-center p-1 rounded text-white px-2.5" style="font-size: 14px;line-height: 1.5;">
                        <svg class="fill-current" width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15 7H9V1C9 0.4 8.6 0 8 0C7.4 0 7 0.4 7 1V7H1C0.4 7 0 7.4 0 8C0 8.6 0.4 9 1 9H7V15C7 15.6 7.4 16 8 16C8.6 16 9 15.6 9 15V9H15C15.6 9 16 8.6 16 8C16 7.4 15.6 7 15 7Z" fill=""></path>
                        </svg>
                        Create Invoice
                    </a>
                @elseif(auth()->user()->hasRole('Manager'))
                    @can('invoice.create')
                        <a href="{{ route('invoices.create') }}" class="bg-primary flex gap-2 hover:bg-opacity-80 items-center p-1 rounded text-white px-2.5" style="font-size: 14px;line-height: 1.5;">
                            <svg class="fill-current" width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15 7H9V1C9 0.4 8.6 0 8 0C7.4 0 7 0.4 7 1V7H1C0.4 7 0 7.4 0 8C0 8.6 0.4 9 1 9H7V15C7 15.6 7.4 16 8 16C8.6 16 9 15.6 9 15V9H15C15.6 9 16 8.6 16 8C16 7.4 15.6 7 15 7Z" fill=""></path>
                            </svg>
                            Create Invoice
                        </a>
                    @endcan
                @endif
            </h2>

            <nav>
                <ol class="flex items-center gap-2">
                    <li><a class="font-medium" href="{{ route('dashboard') }}">Dashboard /</a></li>
                    <li class="font-medium text-primary add-heading">Invoices</li>
                </ol>
            </nav>
        </div>
        <!-- Breadcrumb End -->

        <div class="flex flex-col gap-5 md:gap-7 2xl:gap-10">
            <!-- ====== Data Table Start -->
            <div class="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
                <div class="data-table-common data-table-two max-w-full overflow-x-auto">
                    <table class="table w-full table-auto" id="dataTableTwo">
                        <thead>
                            <tr>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Invoice No</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Date</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Task Ref</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Customer</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Worker</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Invoice Amount</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Paid Amount</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Customer Variable</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Customer Credit</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Customer Debit</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Balance</th>
                                <th class="py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($invoices as $invoice)
                                <tr class="border-b border-gray-200 hover:bg-gray-100">
                                    <td class="py-3 px-4 text-left whitespace-nowrap">
                                        {{ $invoice->invoice_no }}
                                    </td>
                                    <td class="py-3 px-4 text-left whitespace-nowrap">
                                        {{ $invoice->invoice_date }}
                                    </td>
                                    <td class="py-3 px-4 text-left whitespace-nowrap">
                                        {{ $invoice->task->ref_no }}
                                    </td>
                                    <td class="py-3 px-4 text-left">
                                        {{ $invoice->customer->name }}
                                    </td>
                                    <td class="py-3 px-4 text-left">
                                        {{ $invoice->worker->name }}
                                    </td>
                                    <td class="py-3 px-4 text-right whitespace-nowrap">
                                        {{ number_format($invoice->invoice_amount, 2) }}
                                    </td>
                                    <td class="py-3 px-4 text-right whitespace-nowrap">
                                        {{ number_format($invoice->paid_amount, 2) }}
                                    </td>
                                    <td class="py-3 px-4 text-right whitespace-nowrap">
                                        {{ number_format($invoice->customer_variable, 2) }}
                                    </td>
                                    <td class="py-3 px-4 text-right whitespace-nowrap">
                                        {{ number_format($invoice->customer_credit, 2) }}
                                    </td>
                                    <td class="py-3 px-4 text-right whitespace-nowrap">
                                        {{ number_format($invoice->customer_debit, 2) }}
                                    </td>
                                    <td class="py-3 px-4 text-right whitespace-nowrap">
                                        {{ number_format($invoice->balance, 2) }}
                                    </td>
                                    <td class="py-3 px-4">
                                        <div class="flex items-center gap-2">
                                            @if (auth()->user()->hasRole('Admin'))
                                                <a href="{{ route('invoices.edit', $invoice) }}"
                                                class="bg-primary px-2 py-1 rounded text-sm text-white">
                                                    Edit
                                                </a>
                                                <form action="{{ route('invoices.destroy', $invoice) }}"
                                                    method="POST"
                                                    class="inline-block"
                                                    onsubmit="return confirm('Are you sure you want to delete this invoice?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="bg-danger px-2 py-1 rounded text-sm text-white">
                                                        Delete
                                                    </button>
                                                </form>
                                            @elseif(auth()->user()->hasRole('Manager'))
                                                @can('invoice.update')
                                                    <a href="{{ route('invoices.edit', $invoice) }}"
                                                    class="bg-primary px-2 py-1 rounded text-sm text-white">
                                                        Edit
                                                    </a>
                                                @endcan
                                                @can('invoice.delete')
                                                    <form action="{{ route('invoices.destroy', $invoice) }}"
                                                        method="POST"
                                                        class="inline-block"
                                                        onsubmit="return confirm('Are you sure you want to delete this invoice?');">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="bg-danger px-2 py-1 rounded text-sm text-white">
                                                            Delete
                                                        </button>
                                                    </form>
                                                @endcan
                                            @endif
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- ====== Data Table End -->
        </div>
    </div>

@endsection
